﻿# AI bot 1.2 VS AI bot 1.3

=== Overall Battle Results ===
Total battles: 100
Player 1 wins: 84
Player 2 wins: 16
Draws: 0
Average game length: 186.30 moves

=== Overall Battle Results ===
Total battles: 100
Player 1 wins: 76
Player 2 wins: 24
Draws: 0
Average game length: 186.12 moves

=== Overall Battle Results ===
Total battles: 100
Player 1 wins: 84
Player 2 wins: 16
Draws: 0
Average game length: 180.90 moves

=== Overall Battle Results ===
Total battles: 100
Player 1 wins: 86
Player 2 wins: 14
Draws: 0
Average game length: 181.18 moves

=== Overall Battle Results ===
Total battles: 100
Player 1 wins: 97
Player 2 wins: 3
Draws: 0
Average game length: 181.07 moves

=== Overall Battle Results ===
Total battles: 100
Player 1 wins: 77
Player 2 wins: 23
Draws: 0
Average game length: 184.23 moves

# AI bots 1.x < 1.2
- Wasn't ready for starting the script so there is no data about these version.
- So first version of functioning bot was 1.2