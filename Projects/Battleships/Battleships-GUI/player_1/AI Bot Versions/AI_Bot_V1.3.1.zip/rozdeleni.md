# Rozdělení bodů
Martin Novan 100
Rudolf Pažout 100